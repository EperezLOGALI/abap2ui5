# Reporting Security Issues

To report a security issue, please use the GitHub Security Advisory ["Report a Vulnerability"](https://github.com/abapGit/abapGit/security/advisories/new) tab.
